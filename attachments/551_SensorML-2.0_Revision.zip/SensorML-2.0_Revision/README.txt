This directory contains documentation for CR 551:
Proposal for a Concise Specification of an Array of Encoded Values in SensorML-2.0

List of works:

1. CR551_Proposal_for_a_Concise_Specification_of_an_Array_of_Encoded_Values_in_SensorML-2.0.doc
	This is the detailed description of the CR.

2. OGC_12-000_SensorML_2.0_revised_for_CR551.docx
	This is a modified version of OGC 12-000 for the CR
	
3. example (directory)
	Contains 2 XML documents demonstrating the CR.
		a. sensor_instance.xml
			Makes use of setEncodedValues
		b. sensor_model.xml
			Shows how the array encoding can be located in the parent sensor model XML document.
			
4. schema (directory)
	Contains the modified SensorML 2.0 schema. Only configuration.xsd has been altered.
